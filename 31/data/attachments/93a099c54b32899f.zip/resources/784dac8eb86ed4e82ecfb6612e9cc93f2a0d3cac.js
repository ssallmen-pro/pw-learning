// Measure product(item) list views by logging event with an view_item_list parameter and one or more items (i.e. products) defined with the relevant fields
// item_name or item_id is required

var gaProductData = {};
var dataLayer = dataLayer || [];
var scrolling = true;
// processed is used to prevent infinite checking on products if stationary on a position in the list
var processed = false;
// the timeout value that defines the scrolling timing (should slow scrolling also be prevented or not?)
var timeoutValue = 300;
var pushProductsTimeout = setTimeout( function () {
  scrolling = false;
  gaProductData.pushProducts();
}, timeoutValue );

gaProductData.pushProducts = function (event) {
  // only run if the view is steady and there is no scrolling going on
  if(!scrolling && !processed){
    // attempt to have only one process running to push data
    var product = {},
    items = [],
    productData, 
    product;

    // Returns a jQuery object of all <div>s that are within the viewport
    $('.product-is-not-pushed').withinviewport().each( function() {
        $( this ).removeClass( 'product-is-not-pushed' );
        productData = $(this).find('.product-data-container').data('product-data');
        product = createProduct(productData);
        items.push( product );

    });

    // When you scroll do not send an empty push request
    if ( items.length > 0 ) {
        dataLayer.push({
            event: 'view_item_list',
            ecommerce: {
                items
            }
        });

    }
    processed = true;
  }

  // first clear the running timeout before setting it
  clearTimeout(pushProductsTimeout);
  // reset the scrolling flag
  scrolling = false;
  // add the timeout for pushing the products that are in viewport
  pushProductsTimeout = setTimeout( function () {
    gaProductData.pushProducts();
  }, timeoutValue );
};

$( document ).ready( function () {
    // initiate load of default view
    gaProductData.pushProducts();

    // add event listener for scrolling only to indicate scrolling is being done
    document.addEventListener('scroll', (evt) => {
      processed = false;
      scrolling = true;
    }, {
      capture: true,
      passive: true
    })

});

// create product json based on productData object
function createProduct( productData ){
  return {
    item_name: productData.name, 
    item_id:  productData.id ,
    price: productData.price = isNaN(parseFloat(productData.price)) ? null : parseFloat(productData.price), 
    item_category: productData.category,
    supplier: productData.supplier,	
    selection: productData.selection,
    origin: productData.origin,	
    producer: productData.producer,	
    //availability: 'green',	
    size: isNaN(parseFloat(productData.size)) ? null : parseFloat(productData.size),
    alcohol: isNaN(parseFloat(productData.alcohol)) ? null : parseFloat(productData.alcohol),
    packaging: productData.packaging, 
    greenChoice: productData.greenChoice,
    ethical: productData.ethical
  }
}